#!/bin/bash

python plot.py "$1" "$2"
