#!/bin/sh

python index_and_query.py "$1"
